#!/bin/bash
#featureCounts -T 4 -s 2 -p --countReadPairs \
#-a ~/RNASeq_PROJECT/counts/Homo_sapiens.GRCh38.113.gtf.gz \
#-t exon -g gene_id \
#-o ~/RNASeq_PROJECT/counts/counts.txt \
#~/RNASeq_PROJECT/pmapping/SRR30861169.bam \
#~/RNASeq_PROJECT/pmapping/SRR30861170.bam \
#~/RNASeq_PROJECT/pmapping/SRR30861171.bam \
#~/RNASeq_PROJECT/pmapping/SRR30861166.bam \
#~/RNASeq_PROJECT/pmapping/SRR30861167.bam \
#~/RNASeq_PROJECT/pmapping/SRR30861168.bam

grep -v "^#" counts.txt > counts_no_header.txt
cut -f 1,7-12 counts_no_header.txt > counts_filtered.txt
